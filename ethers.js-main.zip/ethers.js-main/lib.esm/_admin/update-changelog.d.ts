export {};
//# sourceMappingURL=update-changelog.d.ts.map