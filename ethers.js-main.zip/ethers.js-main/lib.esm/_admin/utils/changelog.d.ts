export type ChangeVersion = {
    version: string;
    title: string;
    body: Array<string>;
};
export declare function getChanges(): Array<ChangeVersion>;
//# sourceMappingURL=changelog.d.ts.map