export declare function atomicWrite(path: string, value: string | Uint8Array): void;
//# sourceMappingURL=fs.d.ts.map