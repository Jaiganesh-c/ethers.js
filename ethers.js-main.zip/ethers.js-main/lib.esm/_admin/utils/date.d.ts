export declare function getDateTime(date: Date): string;
//# sourceMappingURL=date.d.ts.map