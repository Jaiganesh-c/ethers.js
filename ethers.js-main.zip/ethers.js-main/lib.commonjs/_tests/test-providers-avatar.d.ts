export {};
//# sourceMappingURL=test-providers-avatar.d.ts.map