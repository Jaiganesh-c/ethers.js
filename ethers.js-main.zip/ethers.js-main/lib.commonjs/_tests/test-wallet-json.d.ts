export {};
//# sourceMappingURL=test-wallet-json.d.ts.map