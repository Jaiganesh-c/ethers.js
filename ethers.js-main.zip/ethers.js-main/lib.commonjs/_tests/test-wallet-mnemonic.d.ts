export {};
//# sourceMappingURL=test-wallet-mnemonic.d.ts.map