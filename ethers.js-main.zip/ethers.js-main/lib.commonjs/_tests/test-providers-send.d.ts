export {};
//# sourceMappingURL=test-providers-send.d.ts.map