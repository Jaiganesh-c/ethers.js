export {};
//# sourceMappingURL=test-abi.d.ts.map