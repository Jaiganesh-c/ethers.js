export {};
//# sourceMappingURL=test-providers-errors.d.ts.map