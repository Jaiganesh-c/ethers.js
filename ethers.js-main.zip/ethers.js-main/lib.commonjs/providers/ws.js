"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WebSocket = void 0;
var ws_1 = require("ws");
Object.defineProperty(exports, "WebSocket", { enumerable: true, get: function () { return ws_1.WebSocket; } });
//# sourceMappingURL=ws.js.map