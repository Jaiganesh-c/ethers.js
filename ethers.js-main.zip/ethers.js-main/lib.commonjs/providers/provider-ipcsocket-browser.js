"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IpcSocketProvider = void 0;
const IpcSocketProvider = undefined;
exports.IpcSocketProvider = IpcSocketProvider;
//# sourceMappingURL=provider-ipcsocket-browser.js.map